package testNG;

import org.testng.annotations.Test;

import POM.BankManagerLogin_POM;
import POM.CreateLogin_POM;

import org.testng.annotations.BeforeTest;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class multipletestcases {
	@BeforeTest
	  public void beforeTest() throws InterruptedException 
	  {
		  System.setProperty("webdriver.chrome.driver", "C:\\Automation Folder\\Browser extension\\chromedriver.exe");
		  ChromeDriver driver=new ChromeDriver();
		  driver.manage().window().maximize();
		  driver.manage().deleteAllCookies();
		  Thread.sleep(2000);
	  }
  @Test(priority = 1)
  public void bankmanger() throws InterruptedException 
  {
	  BankManagerLogin_POM s = new BankManagerLogin_POM();
		
	  ChromeDriver driver=new ChromeDriver();
		s.url(driver);
		Thread.sleep(2000);
		s.BankManagerlogin(driver);
		Thread.sleep(2000);
		s.addcustomers(driver);
		Thread.sleep(2000);
		s.openaccountsection(driver);
		Thread.sleep(2000);
	    s.customers(driver);
	    Thread.sleep(2000);
        s.home(driver);
        Thread.sleep(2000);
  }
  
  @Test (priority = 2)
  public void customerlogin() throws InterruptedException 
  {
	  ChromeDriver driver=new ChromeDriver();
	  
	  CreateLogin_POM s = new CreateLogin_POM();
		
		s.url(driver);
		Thread.sleep(2000);
		s.createlogin(driver);
		Thread.sleep(2000);
		s.draganddrop(driver);
		Thread.sleep(2000);
		s.loginbutton(driver);
		Thread.sleep(2000);
		s.transactions(driver);
		Thread.sleep(2000);
		s.back(driver);
		Thread.sleep(2000);
		s.logoutbutton(driver);
		Thread.sleep(2000);
  }

  @AfterTest
  public void afterTest() 
  {
	  ChromeDriver driver=new ChromeDriver();
	  driver.close();
  }

}
