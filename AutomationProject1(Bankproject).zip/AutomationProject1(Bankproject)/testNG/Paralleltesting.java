package testNG;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;

public class Paralleltesting {
	
	@BeforeTest
    public void beforeTest() 
	{
	}
	
   @Test
   public void f() 
   {
   }
  

   @AfterTest
   public void afterTest()  
   {
   }

}
